﻿// forescout.h : Include file for standard system include files,
// or project specific include files.

#pragma once

#include <iostream>
#include <mutex>
#include <unistd.h>
//#include <Windows.h>
#include <thread>
#include <condition_variable>
#include <memory>
#include <any>
#include <list>

using namespace std;

// TODO: Reference additional headers your program requires here.
