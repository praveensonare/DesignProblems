#pragma once

#include "header.h"

template<typename T>
class NetworkMonitor {
private:
    // Periodic Task Thread
    std::unique_ptr<std::thread> mTaskThread;
    // boolean condition for running the task at pre defined interval
    std::atomic_bool mThreadRunning = false;
    
    // assumption: all timestamps are in second
    std::atomic_uint64_t mTaskInterval{};
    std::atomic_uint64_t mCurrentTime{};
    uint64_t mLastTaskExecutionTime{};

    // mutex and conditional_variable to synchronize Add/remove/udpate periodic task
    std::mutex mTaskMutex;
    std::condition_variable mTaskCV;
    std::mutex mProcessDataListMutex;
    std::list<T> mProcessDataList;

    // This is periodic tasj running after fix interval of time
    void periodicTask( )
    {
        while ( mThreadRunning )
        {
            // can be called to remove the periodic task.
            //removePeriodicTask();

            std::unique_lock<std::mutex> lk(mTaskMutex);
            mTaskCV.wait( lk, [&] { return ( mLastTaskExecutionTime + mTaskInterval <= mCurrentTime ) || !mThreadRunning; } );

            if( !mThreadRunning ) break;

            // updating local time with current time
            mLastTaskExecutionTime = mCurrentTime;

            // data processing done here
            ProcessData( );
        }
    }

public:
    NetworkMonitor( ) {};
    NetworkMonitor( const NetworkMonitor& pObj ) = delete;
    NetworkMonitor operator = ( const NetworkMonitor& pObj ) = delete;

    ~NetworkMonitor() {
        if ( mTaskThread )
        {
            mThreadRunning = false;
            mTaskCV.notify_all();
            mTaskThread->join();
        }
    };

    // API to Add Periodic task
    bool addPeriodicTask( const uint64_t pInterval )
    {
        if ( mThreadRunning )
        {
            std::cout << "Periodic Task is already Running ID = " << mTaskThread.get()->get_id() << std::endl;
            return false;
        }

        if( mTaskThread )
        {
            // need to join the previous thread to cleanup and start new thread.
            mTaskThread->join();
            mTaskThread.reset( nullptr );
        }

        mTaskInterval = pInterval;
        mThreadRunning = true;
        mTaskThread.reset( new std::thread( [ this ] ()
            {
                this->periodicTask();
            } )
        );

        std::cout << __FUNCTION__ << " " << __LINE__ << " Created Thread - ID : "<< mTaskThread.get()->get_id() << std::endl;
        return true;
    }

    // API to Remove Periodic Task
    bool removePeriodicTask()
    {
        if( mThreadRunning )
        {
            mThreadRunning = false;
            mTaskCV.notify_all();
            mTaskInterval = {};
            return true;
        }

        std::cout << "There is no running Periodic Task to Remove" << std::endl;
        return false;
    }

    // API to Change the Interval
    bool changeIntervalOfPeriodicTask( const uint64_t pNewInterval )
    {
        if( mThreadRunning )
        {
            if( mTaskInterval == pNewInterval )
            {
              std::cout << "Already Running Periodic Task at Interval " << pNewInterval << std::endl;
              return false;
            }

            std::cout << __FUNCTION__ << " " << __LINE__ << " OldInterval:" << mTaskInterval << "\t NewInterval:" << pNewInterval << std::endl;
            mTaskInterval = pNewInterval;
            mTaskCV.notify_all();
            return true;
        }

        std::cout << "There is no running Periodic Task to Change Interval" << std::endl;
        return false;
    }

    // API to get input time
    void onNewTime( const uint64_t pCurrentTime )
    {
        mCurrentTime = pCurrentTime;
        mTaskCV.notify_all();
        //std::cout << __FUNCTION__ << " " << __LINE__ << " mCurrentTime:" << mCurrentTime << "\t inputTime:" << pCurrentTime << std::endl;
    }

    const uint64_t getCurrentTime() { return mCurrentTime; }

    // methods for dummy data processing in periodic task
    void insertProcessData( const T& pData )
    {
      std::lock_guard<std::mutex> lock( mProcessDataListMutex );
      mProcessDataList.push_back( pData );
    }

    void ProcessData()
    {
      std::lock_guard<std::mutex> lock( mProcessDataListMutex );
      if( mProcessDataList.empty() ) return;

      // assuming very data only contains timestamp.
      while(!mProcessDataList.empty() && mProcessDataList.front() <= mCurrentTime)
      {
        // processing data. in this case pop front element
        mProcessDataList.pop_front();
      }
    }

    const uint64_t getUnProcessedCount()
    {
      const std::lock_guard<std::mutex> lock( mProcessDataListMutex );
      return mProcessDataList.size();
    }
};
