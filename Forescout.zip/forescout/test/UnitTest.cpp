#define BOOST_TEST_MODULE TestSuit
#include <boost/test/included/unit_test.hpp>
#include "CTask.h"
#include "header.h"


BOOST_AUTO_TEST_CASE( test_onNewTime )
{
  NetworkMonitor<uint64_t> OBJ;
  BOOST_TEST( 0 == OBJ.getCurrentTime() );
  BOOST_TEST( 1 != OBJ.getCurrentTime() );
  OBJ.onNewTime( 5 );
  BOOST_TEST( 5 == OBJ.getCurrentTime() );

  OBJ.onNewTime( 6 );
  BOOST_TEST( 5 != OBJ.getCurrentTime() );
}

BOOST_AUTO_TEST_CASE( test_ObjectCreationWithOnNewTime )
{
  NetworkMonitor<uint64_t> OBJ;
  OBJ.onNewTime( 10 );
  BOOST_TEST( OBJ.getCurrentTime() == 10 );
}

BOOST_AUTO_TEST_CASE( test_ObjectCreationWithADD )
{
  NetworkMonitor<uint64_t> OBJ;
  BOOST_TEST( OBJ.addPeriodicTask( 1 ) );
}

BOOST_AUTO_TEST_CASE( test_ObjectCreationWithREMOVE )
{
  NetworkMonitor<uint64_t> OBJ;
  BOOST_TEST( !OBJ.removePeriodicTask() );
}

BOOST_AUTO_TEST_CASE( test_ObjectCreationWithCHANGE_INTERVAL )
{
  NetworkMonitor<uint64_t> OBJ;
  BOOST_TEST( !OBJ.changeIntervalOfPeriodicTask( 6 ) );
}

BOOST_AUTO_TEST_CASE( test_dataProcessing )
{
  NetworkMonitor<uint64_t> OBJ;
  OBJ.addPeriodicTask( 1 );

  OBJ.insertProcessData( 1 );
  OBJ.insertProcessData( 3 );
  OBJ.insertProcessData( 5 );
  OBJ.insertProcessData( 7 );
  OBJ.insertProcessData( 9 );
  OBJ.onNewTime( 3 );
  usleep( 100 );
  BOOST_TEST( OBJ.getUnProcessedCount() == 3 );

  OBJ.onNewTime( 6 );
  usleep( 100 );
  BOOST_TEST( OBJ.getUnProcessedCount() == 2 );

  OBJ.onNewTime( 8 );
  usleep( 100 );
  BOOST_TEST( OBJ.getUnProcessedCount() == 1 );

  OBJ.onNewTime( 9 );
  usleep( 100 );
  BOOST_TEST( OBJ.getUnProcessedCount( ) == 0 );

  OBJ.onNewTime( 10 );
  usleep( 100 );
  BOOST_TEST( OBJ.getUnProcessedCount() == 0 );

}

BOOST_AUTO_TEST_CASE( test_addPeriodicTask )
{
  NetworkMonitor<uint64_t> OBJ;
  BOOST_TEST( OBJ.addPeriodicTask( 4 ) );
  // cant override running task
  BOOST_TEST( !OBJ.addPeriodicTask( 3 ) );

  BOOST_TEST( OBJ.removePeriodicTask() );
  // cant stop if task is not running
  BOOST_TEST( !OBJ.removePeriodicTask() );
}

BOOST_AUTO_TEST_CASE( test_removePeriodicTask )
{
  NetworkMonitor<uint64_t> OBJ;
  BOOST_TEST( !OBJ.removePeriodicTask() );
  BOOST_TEST( OBJ.addPeriodicTask( 4 ) );
  BOOST_TEST( OBJ.removePeriodicTask() );
  BOOST_TEST( OBJ.addPeriodicTask( 4 ) );
  BOOST_TEST( OBJ.changeIntervalOfPeriodicTask( 1 ) );
  BOOST_TEST( OBJ.changeIntervalOfPeriodicTask( 0 ) );
  BOOST_TEST( OBJ.removePeriodicTask() );
}

BOOST_AUTO_TEST_CASE( test_changeIntervalOfPeriodicTask )
{
  NetworkMonitor<uint64_t> OBJ;
  BOOST_TEST( !OBJ.changeIntervalOfPeriodicTask( 0 ) );
  BOOST_TEST( OBJ.addPeriodicTask( 4 ) );
  BOOST_TEST( OBJ.changeIntervalOfPeriodicTask( 1 ) );
  BOOST_TEST( !OBJ.changeIntervalOfPeriodicTask( 1 ) );
  BOOST_TEST( OBJ.changeIntervalOfPeriodicTask( 2 ) );
  BOOST_TEST( OBJ.changeIntervalOfPeriodicTask( 4 ) );
  BOOST_TEST( OBJ.changeIntervalOfPeriodicTask( 8 ) );
  BOOST_TEST( OBJ.removePeriodicTask() );
  BOOST_TEST( !OBJ.changeIntervalOfPeriodicTask( 1 ) );
  BOOST_TEST( OBJ.addPeriodicTask( 4 ) );
  BOOST_TEST( !OBJ.changeIntervalOfPeriodicTask( 4 ) );
}

BOOST_AUTO_TEST_CASE( test_ObjectCreationWithInsertProcessData )
{
  NetworkMonitor<uint64_t> OBJ;

  OBJ.insertProcessData( 1 );
  BOOST_TEST(OBJ.getUnProcessedCount() == 1);
}

BOOST_AUTO_TEST_CASE( test_ObjectCreationWithUnProcessData )
{
  NetworkMonitor<uint64_t> OBJ;

  BOOST_TEST( OBJ.getUnProcessedCount() == 0 );
}
