#!/bin/sh

BUILD_DIR="build"
rm -rf ${BUILD_DIR}

mkdir ${BUILD_DIR}
cd ${BUILD_DIR}
cmake ..
make all
cd ..

echo "****************Test Suit*******************"
./build/test/Forescout_test

./build/Forescout
