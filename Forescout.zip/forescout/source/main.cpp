﻿// forescout.cpp : Defines the entry point for the application.
//

#include "CTask.h"
#include <iostream>
#include <string>

int main() {
    NetworkMonitor<uint64_t> Monitor;
    std::atomic_bool bExe = true;

    // below thread is feeding current time to NetworkMonitor
    std::thread timeInput( [ &Monitor, &bExe ]( )
        {
            for ( uint64_t localTime = 1; bExe ; ++localTime )
            {
                usleep( 1000000 );
                Monitor.onNewTime( localTime );
            }
        });
    
    uint64_t option, interval;
    std::string inputStr;
    
    
    while ( bExe )
    {
        std::cout << "1. Add Periodic Task\n2. Remove Periodic Task\n3. Change Interval\n0. Exit" << std::endl;
        cin >> option;
        switch ( option )
        {
        case 1:
            std::cout << "Input Interval : ";
            cin >> inputStr;
            if( inputStr.empty() || !std::all_of( inputStr.begin(), inputStr.end(), ::isdigit) )
            {
              std::cout << "Input Number - INVALID : " << inputStr << std::endl;
              continue;
            }
            interval = std::stoll( inputStr );
            std::cout << ( Monitor.addPeriodicTask( interval ) ? "Task Added" : "Task Already Running") << std::endl;
            break;
        case 2:
            std::cout << ( Monitor.removePeriodicTask() ? "Task Removed" : "Can't Remove Task - No Task Running") << std::endl;
            break;
        case 3:
            std::cout << "Input Interval : ";
            cin >> inputStr;
            if( inputStr.empty() || !std::all_of( inputStr.begin(), inputStr.end(), ::isdigit) )
            {
              std::cout << "Input Number - INVALID : " << inputStr << std::endl;
              continue;
            }
            interval = std::stoll( inputStr );
            std::cout << ( Monitor.changeIntervalOfPeriodicTask( interval ) ? "New Interval " + std::to_string( interval ) : "Can't changed Interval" ) << std::endl;
            break;
        default:
            bExe = false;
            break;

        }
    }

    timeInput.join();
    return 0;
}
